"""Package for generating random CSV files."""
from random_csv_generator.random_csv import random_csv

__all__ = ["random_csv"]
