"""Current version of package random_csv_generator"""
__version__ = "1.0.0"